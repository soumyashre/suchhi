package com.kpit.demo.databaseoperations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.kpit.demo.bean.Shop;

public class DatabaseOperation {

	

	public void updateShopInfo(Connection connection, Shop shopDetails) {
		try {
			//to do
			PreparedStatement st=connection.prepareStatement("update shop_information set shop_name=?,shop_ownerid=? where shop_id=?");
			st.setString(1, shopDetails.getShop_name());
			st.setString(2, shopDetails.getShop_ownerid());
			st.setString(3, shopDetails.getShop_id());
			st.execute();
			PreparedStatement preparedStatement=connection.prepareStatement("delete from shop_contains where shop_id=?");
			preparedStatement.setString(1, shopDetails.getShop_id());
			System.out.println(shopDetails.getShop_name());
			preparedStatement.execute();
			List<String> items=new ArrayList<String>();
			items=shopDetails.getItems();
			Iterator<String> it=items.iterator();
			

	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
