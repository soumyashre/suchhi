package com.kpit.demo.controller;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.kpit.demo.bean.Shop;
import com.kpit.demo.databaseoperations.DatabaseOperation;

public class Changes extends HttpServlet{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String itemscountinstring=req.getParameter("itemscount");
		int itemscount=Integer.parseInt(itemscountinstring);
		System.out.println("itemscount:"+itemscount);
		System.out.println("Items are");
		List<String> items=new ArrayList<String>();
		for(int i=1;i<=itemscount;i++){
			String name="item"+i;
			System.out.println(req.getParameter(name));
			items.add(req.getParameter(name));
		}
		String shopName=req.getParameter("shopname");
		String id=req.getParameter("shopid");
		String level=req.getParameter("level");
		String owner=req.getParameter("ownerid");
		Shop shopDetails=new Shop();
		shopDetails.setShop_name(shopName);
		shopDetails.setShop_id(id);
		shopDetails.setLevel(level);
		shopDetails.setShop_ownerid(owner);
		shopDetails.setItems(items);
		Iterator<String> it=items.iterator();
		while(it.hasNext()){
			System.out.println("item in list :"+it.next());
		}
		ServletContext context=req.getServletContext();
		Connection connection=(Connection) context.getAttribute("connection");
		DatabaseOperation modal=new DatabaseOperation();
		modal.updateShopInfo(connection,shopDetails);
	}

}
