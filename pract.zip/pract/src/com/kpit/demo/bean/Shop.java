package com.kpit.demo.bean;

import java.util.ArrayList;
import java.util.List;

public class Shop {
	String shop_ownerid;
	String shop_name;
	String level;
	String shop_id;
	List<String> items=new ArrayList<String>();
	public List<String> getItems() {
		return items;
	}
	public void setItems(List<String> items) {
		this.items = items;
	}
	public String getShop_ownerid() {
		return shop_ownerid;
	}
	public void setShop_ownerid(String shop_ownerid) {
		this.shop_ownerid = shop_ownerid;
	}
	public String getShop_name() {
		return shop_name;
	}
	public void setShop_name(String shop_name) {
		this.shop_name = shop_name;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getShop_id() {
		return shop_id;
	}
	public void setShop_id(String shop_id) {
		this.shop_id = shop_id;
	}

}
