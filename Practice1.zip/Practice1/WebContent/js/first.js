$(document).ready(function() {
	console.log("hi");
	value=$("#itemscount").val();
	console.log(value);
	varname=value-1;
		console.log(varname);
		 $("#itemscount").val(varname);
	$("#additembutton").click(function(){
		 varname=varname+1;
	var myform = $('#myform');
	console.log("First:"+varname);
	
	 myform.find('tr').each(function(){
		
         var trow = $(this);
         console.log("this"+this);
         if(trow.index() === 0){
             trow.append('<td></td><br>');
         }else{
             trow.append('<br><td><input type="text" id="item'+varname+'" name="item'+varname+'"/></td><br>');
            
          }
         console.log("Second:"+varname);
        
         });
	 $("#itemscount").val(varname);
	})
	$("#deleteitembutton").click(function(){
	var dd="#item"+varname;
	
	$(dd).remove();
	varname=varname-1;
	$("#itemscount").val(varname);
	});
	
});
