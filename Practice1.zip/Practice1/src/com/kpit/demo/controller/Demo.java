package com.kpit.demo.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kpit.demo.bean.Shop;
import com.kpit.demo.databaseoperations.DatabaseOperation;

public class Demo extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("hi");
		String shopId="g1";
		//Getting connection object to connect to the database
		ServletContext context=req.getServletContext();
		Connection connection=(Connection) context.getAttribute("connection");
		
		DatabaseOperation modal=new DatabaseOperation();
		
		Shop shop=new Shop();
		shop=modal.getShopInfo(connection, shopId);
		req.setAttribute("shopid",shop.getShop_id());
		req.setAttribute("shopname",shop.getShop_name());
		req.setAttribute("level",shop.getLevel());
		req.setAttribute("ownerid",shop.getShop_ownerid());
		
		List<String> list=new ArrayList<String>();
		list=modal.getShopItems(connection, shopId);
		req.setAttribute("list",list);
		
		req.getRequestDispatcher("jsp/form.jsp").forward(req, resp);
		
	}
}
