package com.kpit.demo.databaseoperations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.kpit.demo.bean.Shop;

public class DatabaseOperation {
	public Shop getShopInfo(Connection connection, String shopId) {
		Shop shop = new Shop();
		try {
			PreparedStatement st = connection.prepareStatement("SELECT * FROM shop_information WHERE SHOP_ID=?");
			st.setString(1, shopId);
			ResultSet rs = st.executeQuery();
			List<String> list = new ArrayList<String>();
			while (rs.next()) {
				shop.setLevel(rs.getString("level"));
				shop.setShop_id(rs.getString("shop_id"));
				shop.setShop_name(rs.getString("shop_name"));
				shop.setShop_ownerid(rs.getString("shop_ownerid"));
			}
			PreparedStatement st1 = connection.prepareStatement("SELECT items FROM shop_contains WHERE SHOP_ID=?");
			st1.setString(1, shopId);
			ResultSet rs1 = st1.executeQuery();

			while (rs1.next()) {
				list.add(rs1.getString("items"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block

		}
		return shop;
	}

	public List<String> getShopItems(Connection connection, String shopId) {
		List<String> list = new ArrayList<String>();
		try {
			PreparedStatement st1 = connection.prepareStatement("SELECT items FROM shop_contains WHERE SHOP_ID=?");
			st1.setString(1, shopId);
			ResultSet rs1 = st1.executeQuery();

			while (rs1.next()) {
				list.add(rs1.getString("items"));
			}
		} catch (SQLException e) {
			System.out.println("SQLException" + e.getMessage());
		}
		return list;
	}

	public void updateShopInfo(Connection connection, Shop shopDetails) {
		try {
			// to do
			PreparedStatement st = connection
					.prepareStatement("update shop_information set shop_name=?,shop_ownerid=? where shop_id=?");
			st.setString(1, shopDetails.getShop_name());
			st.setString(2, shopDetails.getShop_ownerid());
			st.setString(3, shopDetails.getShop_id());
			st.execute();
			PreparedStatement preparedStatement = connection
					.prepareStatement("delete from shop_contains where shop_id=?");
			preparedStatement.setString(1, shopDetails.getShop_id());
			System.out.println(shopDetails.getShop_name());
			preparedStatement.execute();
			List<String> items = new ArrayList<String>();
			items = shopDetails.getItems();
			Iterator<String> it = items.iterator();
			while (it.hasNext()) {
				PreparedStatement preparedStatement2 = connection
						.prepareStatement("insert into shop_contains values(?,?)");
				preparedStatement2.setString(1, shopDetails.getShop_id());
				preparedStatement2.setString(2, it.next());
				preparedStatement2.execute();
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
