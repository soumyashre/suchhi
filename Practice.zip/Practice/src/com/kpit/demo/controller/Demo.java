package com.kpit.demo.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kpit.demo.bean.Shop;

public class Demo extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("hi");
		String shopId="g1";
		ServletContext context=req.getServletContext();
		List<String> list=new ArrayList<String>();
		Connection connection=(Connection) context.getAttribute("connection");
		Shop shop=new Shop();
		try {
			PreparedStatement st=connection.prepareStatement("SELECT * FROM shop_information WHERE SHOP_ID=?");
			st.setString(1, shopId);
			ResultSet rs=st.executeQuery();
			while(rs.next()){
				
				shop.setLevel(rs.getString("level"));
				shop.setShop_id(rs.getString("shop_id"));
				shop.setShop_name(rs.getString("shop_name"));
				shop.setShop_ownerid(rs.getString("shop_ownerid"));
			}
			PreparedStatement st1=connection.prepareStatement("SELECT items FROM shop_contains WHERE SHOP_ID=?");
			st1.setString(1, shopId);
			ResultSet rs1=st1.executeQuery();
			
			while(rs1.next()){
				list.add(rs1.getString("items"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			
		}
		
		req.setAttribute("shopid",shop.getShop_id());
		req.setAttribute("shopname",shop.getShop_name());
		req.setAttribute("level",shop.getLevel());
		req.setAttribute("ownerid",shop.getShop_ownerid());
		req.setAttribute("list",list);
		System.out.println(shop);
		
		
		
		
		req.getRequestDispatcher("jsp/form.jsp").forward(req, resp);
		
	}
}
