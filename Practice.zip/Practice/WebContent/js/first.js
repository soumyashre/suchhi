$(document).ready(function() {
	console.log("hi");
	/*$("#additembutton").click(function(){
		alert("hi");
		$("#additembutton").append('<input type="text" ><br>');
		var trow = $(this);
        console.log("this"+this);
        if(trow.index() === 0){
            trow.append('<td></td><br>');
        }else{
            trow.append('<td><input type="text" id="ss" name="ss"/></td><br>');
            var value="#ss";
            console.log(value);
            $(value).val("dd");
          
         }
       
	})*/
	$("#additembutton").click(function(){
	var myform = $('#myform');
	
	 myform.find('tr').each(function(){
         var trow = $(this);
         console.log("this"+this);
         if(trow.index() === 0){
             trow.append('<td></td><br>');
         }else{
             trow.append('<td><input type="text" id="s" name="s"/></td><br>');
             var value="#s";
             /*console.log(value);*/
             $(value).val();
          }
         });
	})
});